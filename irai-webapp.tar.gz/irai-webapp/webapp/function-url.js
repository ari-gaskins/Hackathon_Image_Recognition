// TODO(reader): Replace with the URL of your Cloud Function
// NOTE: cloud function will be exported from project where directory function's main.py was imported
export const CLOUD_FUNCTION_URL = 'https://us-central1-PROJECT_ID.cloudfunctions.net/classify_flower';
